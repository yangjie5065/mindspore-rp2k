通过huaweicloud的modelArts在使用notebook的mindspore集成开发环境，具体配置为
tensorflow1.15-mindspore1.3.0-cann5.0.2.1-ubuntu18.04-aarch6.4
代码运行说明：
在notebook中点击mindspore，得到.ipynb文件先输入!pip3 install tensorbay运行下载tensorbay sdk用于引用数据，
将代码dataset,learningrate,train,eval依次复制到notebook中，notebook上运行。

